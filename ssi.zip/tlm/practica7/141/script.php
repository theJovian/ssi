<?php
	$resultado = system('ls',$returnValue);
	echo $resultado;
	echo $returnValue;
?>
