<?php
	$cmd = fgets(STDIN);
	$result = system($cmd, $cosas);
	echo $result;
	echo $cosas;
?>
