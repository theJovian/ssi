curl localhost:8080/openvpn_udp_roadwarrior.zip --output warrior.zip;
nc -l -p 3000 > intento1.txt;
tac intento1.txt | tr ":" " " | while read A B; do unzip -o -P $B warrior.zip;echo $B; done;
