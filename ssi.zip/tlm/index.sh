#!/bin/bash
file="SecList/Discovery/Web-Content/common.txt"
while read A; do
	echo "HOLA"
	if curl --output /dev/null --silent --head --fail "http://192.168.1.106/$A/index.html"; then
		echo "$A exists"
	fi
done
