#!/bin/bash
file='passwords.txt'
while read A; do
	shh -i $A ana@192.168.1.106  
done;
