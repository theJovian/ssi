##
# This module requires Metasploit: https://metasploit.com/download
# Current source: https://github.com/rapid7/metasploit-framework
##

class MetasploitModule < Msf::Exploit
  def initialize
    super(
      'Name'           => 'MSSQL Ping Utility',
      'Description'    => 'This module simply queries the MSSQL instance for information.',
      'Author'         => 'MC',
      'License'        => MSF_LICENSE,
      'Payload' => {'DisableNops' => true, 'size' => 1024}
    )
  end

  def exploit
    print "holaaaaaa\n"
     end
end
