#!/bin/bash
file='common.txt'
while read line; do
		if curl --output /dev/null --silent --head -fail "http://192.168.1.106/recycle/kiosk/$line/index.html"; then
			echo "http://192.168.1.106/recycle/promotions/$line/index.html"
		fi
	
done < $file
