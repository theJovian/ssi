<?php
	$contenido = file_get_contents("./web1.txt");
	$contenido = str_replace("/", " ", $contenido);
	$contenido = str_replace("|", " ", $contenido);
	$contenido = str_replace("-" , " " ,$contenido);
	$contenido = str_replace('"', " ", $contenido);
	$contenido = str_replace("'", " ", $contenido);
	$contenido = str_replace(",", " ", $contenido);
	$contenido = str_replace(";", " ", $contenido);
	$contenido = str_replace(">", " ", $contenido);
	$contenido = str_replace("<", " ", $contenido);
	$contenido = str_replace("=", " ", $contenido);
	$contenido = str_replace(".", " ", $contenido);
	$contenido = str_replace("(", " ", $contenido);
	$contenido = str_replace(")", " ", $contenido);
	$contenido = str_replace("[", " ", $contenido);
	$contenido = str_replace("]", " ", $contenido);
	$contenido = str_word_count($contenido, 1);	
	$nuevoContenido = array();
	for($i = 0; $i < count($contenido); $i++){
		if(strlen($contenido[$i]) < 8 && ctype_lower($contenido[$i])){
			if(!in_array($contenido[$i], $nuevoContenido))
				array_push($nuevoContenido, $contenido[$i]);
		}
	}
	for($i = 0 ; $i < count($nuevoContenido); $i++){
			file_put_contents("./passwords.txt", $nuevoContenido[$i] . "\n", FILE_APPEND);
	}
		
?>
